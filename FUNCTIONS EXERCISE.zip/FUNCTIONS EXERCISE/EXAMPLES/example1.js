//Define a function that greets someone in Uganda:
function greetUgandan(name) {
console.log(`Hello ${name}, welcome to Uganda!`);
}
greetUgandan("Angellah");