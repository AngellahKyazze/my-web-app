//Example 9: Using IIFE
 (function () {
 console.log("This function runs immediately!");
 })();