let calculateArea = (length, width) => {
    let area = length * width;
    return area;
};

// Example usage:
let length = 50; 
let width = 10;  
console.log("Area of the plot:", calculateArea(length, width), "square meters");
