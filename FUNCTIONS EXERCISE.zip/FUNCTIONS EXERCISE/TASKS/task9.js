(function() {
    console.log("Welcome to JavaScript in Uganda!");
})();
