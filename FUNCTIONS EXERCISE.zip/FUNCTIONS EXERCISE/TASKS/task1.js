//creating name
function greetStudent(name) {
    console.log(`Hello ${name}, you are attending the JavaScript class!`);
}

//calling name
greetStudent("Angellah");
