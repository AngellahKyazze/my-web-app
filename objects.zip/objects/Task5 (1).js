//object school
let school = {
    name: "Ndejje SSS",
    schoolLocation: "ndejjje",
    establishedYear:1999,
    studentsCount:100
};

for (let key in school){
    console.log(`${key}: ${school[key]}`);
}