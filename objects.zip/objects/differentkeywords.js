//variable that stores the student name and no of students in the IT class
var Name = "Angellah";
const no_of_students = 123;


console.log("Name of the student is :",Name, "no_of_students is :",no_of_students);


