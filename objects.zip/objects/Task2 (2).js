//object school
let school = {
    name: "Ndejje SSS",
    schoolLocation: "ndejje",
    establishedYear:1990,
    studentsCount:10000
};

//adding an object
school.schoolType = "Secondary";
//modifying the studentCount
school.studentsCount = "18";
console.log(school);


