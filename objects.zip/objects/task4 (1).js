let university = {
    name: "NdejjeUniversity",
    location: "mukono",
    departments: {
        computerScience: {
            name: "Computer Science",
            headOfDepartment: " Cathy"
        },
        journalism: {
            name: "Business Administration",
            headOfDepartment: " Martha"
        }
        
    }
};

// Log the head of the Computer Science department
console.log(`The head of the Computer Science department is ${university.departments.computerScience.headOfDepartment}.`);
