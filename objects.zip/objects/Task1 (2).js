//object school
let school = {
    name: "Ndejje s.s.s",
    schoolLocation: "ndejje",
    establishedYear:1999,
    studentsCount:100
};
//log schoolname and location
console.log(`school's name:${school.name}`);
console.log(`location:${school.schoolLocation}`);