//object school
let school = {
    name: "Ndejje SSS",
    schoolLocation: "ndejje",
    establishedYear:1999,
    studentsCount:100
};

let {name, schoolLocation,studentsCount } =school ;

console.log(`${name} is located in ${schoolLocation} and has${studentsCount}students.`);